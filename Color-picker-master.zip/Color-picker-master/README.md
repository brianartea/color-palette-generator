﻿# Color-picker

An application where you can create and save your palettes
[coloor.work](https://coloor.work)
---

#### About

- Made for learning purposes
- Made with javascript
- Using [chromajs framework](https://gka.github.io/chroma.js/)

![img1](https://s6.gifyu.com/images/ezgif-7-21d993846be6.gif)

#### You can also copy the colors

![img3](https://s6.gifyu.com/images/ezgif-7-5d38204e9c69.gif)
